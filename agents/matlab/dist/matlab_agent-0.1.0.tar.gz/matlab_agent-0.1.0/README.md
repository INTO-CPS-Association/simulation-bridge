# MATLAB agent

The MATLAB Agent is a Python-based connector designed to interface with MATLAB simulations through various methods. It provides the following functionalities:

- **Batch Simulation**: Executes predefined MATLAB routines with specified input parameters, collecting the final results upon completion.
- **Streaming Simulation (Agent-Based)**: Allows sending input once, with the output being received in real-time during the simulation.

The MATLAB Agent is primarily built to integrate with the Simulation Bridge but can also be utilized by external systems via RabbitMQ exchange methods. Communication parameters and other settings are defined in the configuration file located at `matlab_agent/config/config.yaml`.

<div align="center">
  <img src="matlab_agent/images/structure.png" alt="MATLAB Agent Structure" width="600" style="border: 1px solid #ddd; border-radius: 4px; padding: 5px;">
</div>

## Requirements

To integrate MATLAB with the Simulation Bridge, install the MATLAB Engine API for Python. Follow the official MathWorks installation guide for detailed steps:

[MATLAB Engine API for Python Installation Guide](https://www.mathworks.com/help/matlab/matlab-engine-for-python.html)

> **Installation on macOS**
>
> For macOS users (e.g., MATLAB R2024b), execute the following commands:
>
> ```bash
> poetry env activate
> cd /Applications/MATLAB_R2024b.app/extern/engines/python
> python -m pip install .
> ```
>
> **Note:** Replace `MATLAB_R2024b.app` with the version installed on your system.

Verify that the MATLAB Engine is properly installed and accessible within your Python environment.

### Configuration

Create a `config.yaml` file with the following structure:

```yaml
agent:
  agent_id: matlab # Specifies the unique identifier for the agent. This ID is used to distinguish the agent in the system.

rabbitmq:
  host: localhost # The hostname or IP address of the RabbitMQ server.
  port: 5672 # The port number for RabbitMQ communication (default is 5672).
  username: guest # The username for authenticating with RabbitMQ.
  password: guest # The password for authenticating with RabbitMQ.
  heartbeat: 600 # The heartbeat interval (in seconds) to keep the connection alive.

simulation:
  path: /Users/marcomelloni/Desktop/AU_University/simulation-bridge/agents/matlab/matlab_agent/docs/examples # The file path to the folder containing MATLAB simulation files.

exchanges:
  input: ex.bridge.output # The RabbitMQ exchange from which the agent receives commands.
  output: ex.sim.result # The RabbitMQ exchange to which the agent sends simulation results.

queue:
  durable: true # Ensures that the queue persists across RabbitMQ broker restarts.
  prefetch_count: 1 # Limits the number of unacknowledged messages the agent can receive at a time.

logging:
  level: INFO # Specifies the logging level. Options include DEBUG, INFO, and ERROR.
  file: logs/matlab_agent.log # The file path where logs will be stored.

tcp:
  host: localhost # The hostname or IP address for TCP communication.
  port: 5678 # The port number for TCP communication.

response_templates:
  success:
    status: success # Indicates a successful simulation response.
    simulation:
      type: batch # Specifies the type of simulation (e.g., batch or streaming).
    timestamp_format: "%Y-%m-%dT%H:%M:%SZ" # The timestamp format in ISO 8601 with a Z suffix for UTC.
    include_metadata: true # Determines whether metadata is included in the response.
    metadata_fields: # Specifies the metadata fields to include in the response.
      - execution_time
      - memory_usage
      - matlab_version

  error:
    status: error # Indicates an error response.
    include_stacktrace: false # For security, stack traces are excluded in production environments.
    error_codes: # Maps specific error scenarios to HTTP-like status codes.
      invalid_config: 400 # Error code for invalid configuration.
      matlab_start_failure: 500 # Error code for MATLAB startup failure.
      execution_error: 500 # Error code for simulation execution errors.
      timeout: 504 # Error code for simulation timeout.
      missing_file: 404 # Error code for missing files.

    timestamp_format: "%Y-%m-%dT%H:%M:%SZ" # The timestamp format in ISO 8601 with a Z suffix for UTC.

  progress:
    status: in_progress # Indicates that the simulation is currently in progress.
    include_percentage: true # Includes the percentage of completion in progress updates.
    update_interval: 5 # Specifies the interval (in seconds) for sending progress updates.
    timestamp_format: "%Y-%m-%dT%H:%M:%SZ" # The timestamp format in ISO 8601 with a Z suffix for UTC.
```

To use a custom `config.yaml` file, run the `matlab-agent` command with the `--config-path` or `-c` option followed by the path to your configuration file:

```bash
matlab-agent --config-path <path_to_your_config.yaml>
```

## Usage

To start the MATLAB Agent with the default configuration:

1. Open a terminal and navigate to the project's root directory.
2. Run the following command:

```bash
matlab-agent
```

To use a custom configuration file, provide its path using the `--config-path` option:

```bash
matlab-agent --config-path <path_to_config.yaml>
```

Alternatively, you can use the shorthand `-c` option:

```bash
matlab-agent -c <path_to_config.yaml>
```

## Testing

For instructions on running tests created with `pytest` and `unittest.mock`, please refer to the [Tests Documentation](matlab_agent/tests/README.md).

## Quick Start: Interacting with the Matlab agent

To quickly begin using the MATLAB Agent, refer to the example script in the `resources` folder:

```plaintext
resources/use_matlab_agent.py
```

This script demonstrates how to interact with the MATLAB Agent, providing a clear example of its functionality and integration process.

## Workflow

1. The agent connects to RabbitMQ and sets up the required queues and exchanges.
2. It listens for incoming messages on its dedicated queue.
3. Upon receiving a message:

- It analyzes and processes the simulation request.
- Executes the simulation.
- Sends the results to the output exchange.

For detailed information regarding simulations and constraints, please refer to the [Simulations and Constraints Documentation](matlab_agent/docs/README.md).

## Author

<div align="left" style="display: flex; align-items: center; gap: 15px;">
  <img src="matlab_agent/images/profile.jpg" width="60" style="border-radius: 50%; border: 2px solid #eee;"/>
  <div>
   <h3 style="margin: 0;">Marco Melloni</h3>
   <div style="margin-top: 5px;">
    <a href="https://www.linkedin.com/in/marco-melloni/">
      <img src="https://img.shields.io/badge/LinkedIn-Connect-blue?style=flat-square&logo=linkedin"/>
    </a>
    <a href="https://github.com/marcomelloni" style="margin-left: 8px;">
      <img src="https://img.shields.io/badge/GitHub-Profile-black?style=flat-square&logo=github"/>
    </a>
   </div>
  </div>
</div>
